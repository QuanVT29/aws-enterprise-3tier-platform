import boto3
import json

def lambda_handler(event, context):
    arn = event['SecretId']
    token = event['ClientRequestToken']
    step = event['Step']
    print(f"Executing step {step} for secret {arn}")
    return {"statusCode": 200, "body": json.dumps("Rotation step processed")}
